package com.example.kullanicigirisi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.kullanicigirisi.databinding.ActivityMainBinding;

import java.util.concurrent.CountedCompleter;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding bingding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bingding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = bingding.getRoot();
        setContentView(view);

    }
    public void kullaniciGirisi(View view){
        String kullaniciAdi = bingding.editTextTextKullaniciAdi.getText().toString();
        String parola = bingding.editTextTextKullaniciParola.getText().toString();

        Singleton singleton = Singleton.getInstance();
        singleton.setKullaniciAdi(kullaniciAdi);
        singleton.setKullaniciParola(parola);

        Intent intent = new Intent(this,AnaSayfa.class);
        startActivity(intent);
    }

}